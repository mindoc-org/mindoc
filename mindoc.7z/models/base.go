package models

type Model struct {

}

